<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="con">

<div class="heading">User login</div>
<form action="login" method="post" class="form">
<div class="input-field">
<input type="text" required autocomplete="off" name="name">
<label for="username">User Name</label>
</div>
<div class="input-field">
<input type="password" required autocomplete="off" name="password">
<label for="username">password</label>
</div>
<div class="btn-con">
<button class="btn1">Submit</button>
<div class="acc-text">
<p>New User?<a href="register.jsp" style="color:#0000ff; cursor: pointer;">Start Here</a></p></div>
</div>


</form>


</div>
</body>
</html>