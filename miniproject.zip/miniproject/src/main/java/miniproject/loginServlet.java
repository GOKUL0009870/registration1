package miniproject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/login")
public class loginServlet  extends HttpServlet{
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		String username=request.getParameter("name");
		String password=request.getParameter("password");
		String sql="SELECT * FROM users WHERE name=? AND password=?";
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","gokul0907");
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				HttpSession session=request.getSession();
				session.setAttribute("username",rs.getString("name"));
				response.sendRedirect("welcome.jsp");
			}
			else {
				response.getWriter().println("Invaild !!!!");
			}
			
		} catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
