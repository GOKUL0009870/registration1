package miniproject;



import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws IOException {

        String name=request.getParameter("name");
        String email= request.getParameter("email");
       
		
        String password=request.getParameter("password");
        try {
        	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","gokul0907");
        	String sql="INSERT INTO users(name,email,password)values(?,?,?)";
        	PreparedStatement pst=con.prepareStatement(sql);
        	pst.setString(1, name);
        	pst.setString(2, email);
        	
        	pst.setString(3, password);
        	int row=pst.executeUpdate();
        	if(row>0) {
        		response.sendRedirect("login.jsp");	
        	}
        	else {
        		response.getWriter().println("registration failed");
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        }

	
}
}
